﻿using RosebankCollege_ClaimSystem.Models;
using System.ComponentModel.DataAnnotations;

namespace RosebankCollege_ClaimSystem.Models
{
    public class employeeCreateUpdate
    {
        public int? Id { get; set; }
        [Display(Name = "Full Name")]
        [Required(ErrorMessage = "Full Name is required")]
        [StringLength(100)]
        public string FullName { get; set; } = null!;
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress]
        public string Email { get; set; } = null!;
        [Display(Name = "Department")]
        [Required(ErrorMessage = "Department is required")]
        public int DepartmentId { get; set; }
        [Display(Name = "Designation")]

        [Required(ErrorMessage = "Designation is required")]
        public int DesignationId { get; set; }
        [Display(Name = "Hire Date")]
        [Required(ErrorMessage = "Hire Date is required")]
        [DataType(DataType.Date)]
        [CustomValidation(typeof(employeeCreateUpdate), nameof(ValidateHireDate))]
        public DateTime HireDate { get; set; } = DateTime.Today;

        [Display(Name = "Employee Type")]
        [Required(ErrorMessage = "Employee Type is required")]
        public int EmployeeTypeId { get; set; }

        [Required(ErrorMessage = "Salary is required")]
        [Range(0, double.MaxValue)]
        public decimal Salary { get; set; }
        // For dropdown lists
        public List<department>? Departments { get; set; }
        public List<programmeRole>? programmeRoles { get; set; }
        public List<employeeDetails>? employeeDetails { get; set; }
        // Validation methods:
        public static ValidationResult? ValidateHireDate(DateTime? hireDate, ValidationContext context)
        {
            if (!hireDate.HasValue)
                return new ValidationResult("Hire Date is required.");
            if (hireDate.Value.Date > DateTime.Today)
                return new ValidationResult("Hire Date cannot be in the future.");
            return ValidationResult.Success;
        }
    }
}
