﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RosebankCollege_ClaimSystem.Models
{
    public class employee
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Full Name is required")]
        [StringLength(100, ErrorMessage = "Full Name cannot be longer than 100 characters")]
        public string FullName { get; set; } = null!;
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; } = null!;
        [Required(ErrorMessage = "Department is required")]
        public int DepartmentId { get; set; }
        public department Department { get; set; } = null!;
        [Required(ErrorMessage = "Designation is required")]
        public int DesignationId { get; set; }
        public programmeRole programmeRole { get; set; } = null!;
        [Required(ErrorMessage = "Hire Date is required")]
        [DataType(DataType.Date)]
        public DateTime HireDate { get; set; }
       
        public int EmployeeTypeId { get; set; }
        public employeeDetails EmployeeType { get; set; } = null!;
        [Required(ErrorMessage = "Hourly rate  is required")]
        public int HourlyRate { get; set; } 

        [Required(ErrorMessage = "Salary is required")]
        [Range(0, double.MaxValue, ErrorMessage = "Salary must be a positive number")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Salary { get; set; }
        public string Status { get; set; } = "Pending";  // Accepted, Rejected


    }
}
