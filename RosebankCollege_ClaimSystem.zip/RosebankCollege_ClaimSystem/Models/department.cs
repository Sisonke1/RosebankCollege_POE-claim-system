﻿namespace RosebankCollege_ClaimSystem.Models
{
    public class department
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public bool IsActive { get; set; }
        public ICollection<programmeRole>? ProgrammeRoles { get; set; } = new List<programmeRole>();
        public List<employeeDetails>? EmployeeDetails { get; set; }
    }
}
