﻿namespace RosebankCollege_ClaimSystem.Models
{
    public class programmeRole
    {
            public int Id { get; set; }
            public string Name { get; set; } = null!;
            public int DepartmentId { get; set; }
            public department Department { get; set; } = null!;
            public bool IsActive { get; set; }
      
}
}
