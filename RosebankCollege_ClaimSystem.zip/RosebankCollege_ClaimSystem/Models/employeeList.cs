﻿namespace RosebankCollege_ClaimSystem.Models
{
    public class employeeList
    {
        public List<employee>? Employees { get; set; }
        public int TotalPages { get; set; }
        public string? SearchTerm { get; set; }
        public int? SelectedDepartmentId { get; set; }
        public int? SelectedEmployeeTypeId { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
        public int Total { get; set; }
        public List<department>? Departments { get; set; }
        public List<employeeDetails>? EmployeeDetails { get; set; }
    }
}
