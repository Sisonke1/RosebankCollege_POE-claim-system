create database RosebankDB;
create table employeeDetails 
(
 employeeId varchar(10) primary key not null,
 Names varchar(50) not null
);

create table employee 
(
 Id varchar(100) primary key not null,
 FullNames varchar(50) not null,
 Email varchar(50) not null,
 Department varchar(100) not null,
 ProgrammeRole varchar(50) not null,
 HireDate date not null,
 EmployeeType varchar(50) not null,
 Hourly_Rate int not null,
 Salary float not null,
 Status varchar(10) not null
);

create table department
(
 departmentId varchar(10) primary key not null,
 Names varchar(50) not null
);

create table programmeRole 
(
 programmeId varchar(50) not null,
 Names varchar(50) not null,
 departmentId varchar(10) foreign key references department(departmentId) not null
);