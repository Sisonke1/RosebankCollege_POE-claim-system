﻿using RosebankCollege_ClaimSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace RosebankCollege_ClaimSystem.Data
{
    public class RosebankDBcontext : DbContext
    {
        public RosebankDBcontext(DbContextOptions<RosebankDBcontext> options) 
        : base(options)
        { }
        public DbSet<employee> employees { get; set; }
        public DbSet<department> Departments { get; set; }
        public DbSet<programmeRole> programmeRoles { get; set; }
        public DbSet<employeeDetails> employeeDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<employee>()
           .HasOne(e => e.programmeRole)
           .WithMany()
           .HasForeignKey(e => e.DesignationId)
           .OnDelete(DeleteBehavior.Restrict);

            // Seed data for Departments
            modelBuilder.Entity<department>().HasData(
                new department { Id = 1, Name = "Human Resources" },
                new department { Id = 2, Name = "Finance" },
                new department { Id = 3, Name = "IT" },
                new department { Id = 4, Name = "Marketing" }
            );
            // Seed data for programmeRoles
            modelBuilder.Entity<programmeRole>().HasData(
                new programmeRole { Id = 1, Name = "Manager" },
                new programmeRole { Id = 2, Name = "Developer" },
                new programmeRole { Id = 3, Name = "Analyst" },
                new programmeRole { Id = 4, Name = "Intern" }
           
            );
            // Seed data for employeeDetails
            modelBuilder.Entity<employeeDetails>().HasData(
                new employeeDetails { Id = 1, Name = "Full-Time", IsActive = true },
                new employeeDetails { Id = 2, Name = "Part-Time", IsActive = true },
                new employeeDetails { Id = 3, Name = "Contractor", IsActive = true }
            );

            modelBuilder.Entity<employee>().HasData(
                new employee { Id = 1, FullName = "John Doe", Email = "john@example.com", DepartmentId = 1, DesignationId = 1, HireDate = new DateTime(2020, 1, 15), EmployeeTypeId = 1, Status = "Pending", Salary = 60000m },
                new employee { Id = 2, FullName = "Jane Smith", Email = "jane@example.com", DepartmentId = 2, DesignationId = 5, HireDate = new DateTime(2018, 5, 20), EmployeeTypeId = 1, Status = "Pending", Salary = 80000m },
                new employee { Id = 3, FullName = "Sam Wilson", Email = "sam@example.com", DepartmentId = 3, DesignationId = 7, HireDate = new DateTime(2021, 3, 10), EmployeeTypeId = 3, Status = "Accepted", Salary = 50000m },
                new employee { Id = 4, FullName = "Anna Taylor", Email = "anna@example.com", DepartmentId = 4, DesignationId = 11, HireDate = new DateTime(2022, 7, 5), EmployeeTypeId = 2, Status = "Rejected", Salary = 40000m },
                new employee { Id = 5, FullName = "Tom Brown", Email = "tom@example.com", DepartmentId = 1, DesignationId = 3, HireDate = new DateTime(2019, 4, 18), EmployeeTypeId = 1, Status = "Rejected", Salary = 70000m },
                new employee { Id = 6, FullName = "Emma Davis", Email = "emma@example.com", DepartmentId = 2, DesignationId = 4, HireDate = new DateTime(2017, 10, 12), EmployeeTypeId = 1, Status = "Pending", Salary = 75000m },
                new employee { Id = 7, FullName = "Luke Miller", Email = "luke@example.com", DepartmentId = 3, DesignationId = 8, HireDate = new DateTime(2020, 2, 20), EmployeeTypeId = 3, Status = "Pending", Salary = 85000m },
                new employee { Id = 8, FullName = "Olivia Johnson", Email = "olivia@example.com", DepartmentId = 4, DesignationId = 10, HireDate = new DateTime(2021, 6, 8), EmployeeTypeId = 1, Status = "Accepted", Salary = 65000m },
                new employee { Id = 9, FullName = "Mia Moore", Email = "mia@example.com", DepartmentId = 1, DesignationId = 2, HireDate = new DateTime(2022, 8, 15), EmployeeTypeId = 4, Status = "Accepted", Salary = 30000m },
                new employee { Id = 10, FullName = "Chris Evans", Email = "chris@example.com", DepartmentId = 2, DesignationId = 6, HireDate = new DateTime(2018, 11, 25), EmployeeTypeId = 2, Status = "Rejected", Salary = 55000m },
                new employee { Id = 11, FullName = "Sophia White", Email = "sophia@example.com", DepartmentId = 3, DesignationId = 7, HireDate = new DateTime(2019, 9, 10), EmployeeTypeId = 1, Status = "Accepted", Salary = 52000m },
                new employee { Id = 12, FullName = "Liam Green", Email = "liam@example.com", DepartmentId = 4, DesignationId = 12, HireDate = new DateTime(2020, 10, 3), EmployeeTypeId = 2, Status = "Pending", Salary = 38000m },
                new employee { Id = 13, FullName = "Noah Black", Email = "noah@example.com", DepartmentId = 1, DesignationId = 2, HireDate = new DateTime(2018, 12, 1), EmployeeTypeId = 1, Status = "Pending", Salary = 65000m },
                new employee { Id = 14, FullName = "Isabella Blue", Email = "isabella@example.com", DepartmentId = 2, DesignationId = 4, HireDate = new DateTime(2017, 11, 30), EmployeeTypeId = 1, Status = "Accepted", Salary = 76000m },
                new employee { Id = 15, FullName = "James Brown", Email = "james@example.com", DepartmentId = 3, DesignationId = 9, HireDate = new DateTime(2021, 7, 21), EmployeeTypeId = 3, Status = "Rejected", Salary = 62000m }

                );
        }
    }
    }

